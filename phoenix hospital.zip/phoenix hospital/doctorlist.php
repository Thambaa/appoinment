<?php
include 'db.php';

$sql = "SELECT doctor_id, name, specialization, day, profile_image, in_time, out_time FROM doctors";
$result = $conn->query($sql);

function convertTo12HourFormat($time) {
    $date = DateTime::createFromFormat('H:i:s', $time);
    return $date->format('h:i A');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find a Consultant</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
        }
        .doctor-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            margin-top: 20px;
        }
        .doctor-card {
            border: 1px solid #ddd;
            padding: 20px;
            margin: 10px;
            border-radius: 10px;
            background-color: #fff;
            color: #333;
            text-align: center;
            width: 250px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .doctor-card:hover {
            transform: translateY(-5px);
        }
        .doctor-card img {
            max-width: 100px;
            max-height: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
        }
        .doctor-card h2 {
            margin: 5px 0;
            font-size: 18px;
        }
        .doctor-card p {
            margin: 5px 0;
            font-size: 14px;
        }
        .consulting-hours {
            
            margin-top: 0;
            font-size: 14px;
            margin-bottom: 5px; /* Added space below Consulting Hours */
        }

        .consulting-hours h4 {
            margin: 0;
            font-size: 16px; /* Adjust font size */
        }
        .appointment-button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #04AA6D;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }
        .appointment-button:hover {
            opacity: 0.8;
        }
    </style>
</head>
<body>
<?php 


// Check if the user is accessing appointments from the admin dashboard
if (basename($_SERVER['HTTP_REFERER']) === 'admin_dashboard.php') {
    // If accessed from admin_dashboard.php, include staffheader.php
    include "staffheader.php";
} else {
    // Otherwise, include patientheader.php
    include "patientheader.php";
}


?>
    <h1>Book a Medical Consultant</h1>
    <div class="doctor-container">
    <?php
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $profile_image = $row["profile_image"] ? $row["profile_image"] : './img/dr.png';
                $in_time_12hr = convertTo12HourFormat($row["in_time"]);
                $out_time_12hr = convertTo12HourFormat($row["out_time"]);

                echo "<div class='doctor-card'>";
                echo "<img src='" . $profile_image . "' alt='Profile Image'>";
                echo "<h2>Dr. " . $row["name"] . "</h2>";
                echo "<p>Consulted Type: " . $row["specialization"] . "</p>";
                echo "<div class='consulting-hours'>";
                echo "<h4>Consulting Hours:</h4>";
                echo "<p>From " . $in_time_12hr . " - "." To " . $out_time_12hr . "</p>";
                echo "</div>";
                echo "<p>Available Day: " . $row["day"] . "</p>";
                echo "<button class='appointment-button' onclick='selectDoctor(" . $row["doctor_id"] . ")'>Make an Appointment</button>";
                echo "</div>";
            }
        } else {
            echo "No doctors available.";
        }
    ?>






    </div>
    <script>
        function selectDoctor(doctorId) {
            // Redirect to appointments.php with the doctor_id and specify where the appointment is made from
            window.location.href = "appointments.php?doctor_id=" + doctorId + "&from=doctorlist";
        }
    </script>
</body>
</html>

<?php
$conn->close();
?>
