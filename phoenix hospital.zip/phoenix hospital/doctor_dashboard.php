<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'doctor') {
    header("Location: login.php");
    exit();
}

include "db.php";

// Function to calculate age from date of birth
function calculateAge($dob) {
    $dob = new DateTime($dob);
    $now = new DateTime();
    $age = $now->diff($dob)->y;
    return $age;
}

// Function to handle database errors
function handleDatabaseError($conn, $errorMessage) {
    // Log detailed error message for developer
    error_log("Database Error: " . $conn->error);
    // Display user-friendly error message
    echo "<div class='alert alert-danger' role='alert'>$errorMessage</div>";
}

// Fetch the details of the logged-in doctor
$doctorId = $_SESSION['user_id']; // Assuming the doctor's ID is stored in the session
$sql = "SELECT * FROM doctors WHERE user_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    handleDatabaseError($conn, "Failed to prepare statement");
    exit();
}

$stmt->bind_param("i", $doctorId);
$stmt->execute();
$result = $stmt->get_result();

if ($result === false) {
    handleDatabaseError($conn, "Failed to execute statement");
    exit();
}

if ($result->num_rows > 0) {
    $doctor = $result->fetch_assoc();
} else {
    handleDatabaseError($conn, "Doctor not found");
}

// Check if prescription data is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['savePrescription'])) {
    $appointmentId = $_POST['appointmentId'];
    $prescription = $conn->real_escape_string($_POST['prescription']);

    // Fetch appointment data
    $appointmentSql = "SELECT * FROM appointments WHERE id = ?";
    $appointmentStmt = $conn->prepare($appointmentSql);
    $appointmentStmt->bind_param("i", $appointmentId);
    $appointmentStmt->execute();
    $appointmentResult = $appointmentStmt->get_result();

    if ($appointmentResult->num_rows > 0) {
        $appointmentData = $appointmentResult->fetch_assoc();
        $patientId = $appointmentData['id'];

        // Update prescription for the patient in patients table
        $updateSql = "UPDATE patients SET prescription = ? WHERE appointment_id = ?";
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("si", $prescription, $patientId);
        
        if ($updateStmt->execute()) {
            echo "Prescription added successfully.";
            exit; // Exit after handling the AJAX request
        } else {
            echo "Error adding prescription: " . $conn->error;
            exit; // Exit after handling the AJAX request
        }
    } else {
        echo "Appointment not found.";
        exit; // Exit after handling the AJAX request
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container-box {
            background-color: #ffffff;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .table {
            margin-top: 20px;
            border-collapse: separate;
            border-spacing: 0;
            border-radius: 5px;
            width: 100%;
        }
        .table th, .table td {
            padding: 12px 15px;
            border-bottom: 1px solid #dee2e6;
        }
        .table thead th {
            background-color: #007bff;
            color: #ffffff;
            text-align: left;
            border-top: none;
        }
        .table tbody tr:nth-of-type(odd) {
            background-color: #f9f9f9;
        }
        .table tbody tr:hover {
            background-color: #f1f1f1;
        }
        .profile-overview {
            background-color: #f1f1f1;
            padding: 15px;
            border-radius: 5px;
        }
        .profile-overview h2 {
            text-align: center;
            margin-bottom: 15px;
        }
        .profile-overview h4 {
            margin-bottom: 15px;
        }
        .img-fluid{
            width: 150px; 
            height: 150px;
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <?php include "staffheader.php";?>
        
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8">
                <div class="container-box">
                    <h2 class="mb-4">Welcome, <?php if($result->num_rows > 0) { echo "Dr. " . htmlspecialchars($doctor['name']);} ?></h2>
                    <h3>Your Appointments</h3>
                    <div id="doctorAppointments">
                        <?php
                        // Perform SQL query to fetch appointments for this doctor
                        $sql = "SELECT id, patient_name, dob, gender, blood_group, appointment_date FROM appointments WHERE doctor_id = ?";
                        $stmt = $conn->prepare($sql);

                        if ($stmt === false) {
                            handleDatabaseError($conn, "Failed to prepare statement");
                            exit();
                        }

                        $stmt->bind_param("i", $doctor['doctor_id']);
                        $stmt->execute();
                        $result = $stmt->get_result();

                        if ($result === false) {
                            handleDatabaseError($conn, "Failed to execute statement");
                            exit();
                        }

                        if ($result->num_rows > 0) {
                            // Output appointments data
                            echo "<table class='table table-bordered'>";
                            echo "<thead class='thead-light'><tr><th>ID</th><th>Patient Name</th><th>Age</th><th>Gender</th><th>Blood Group</th><th>Appointment Date</th><th>Prescription</th></tr></thead><tbody>";
                            while ($row = $result->fetch_assoc()) {
                                $age = calculateAge($row["dob"]);
                                echo "<tr>";
                                echo "<td>" . htmlspecialchars($row["id"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["patient_name"]) . "</td>";
                                echo "<td>" . htmlspecialchars($age) . "</td>";
                                echo "<td>" . htmlspecialchars($row["gender"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["blood_group"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["appointment_date"]) . "</td>";
                                echo "<td><button type='button' class='btn btn-primary' onclick='addPrescription(" . $row["id"] . ")'>Add Prescription</button></td>";
                                echo "</tr>";
                            }
                            echo "</tbody></table>";
                        } else {
                            echo "<div class='alert alert-info'>No appointments found</div>";
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="container-box profile-overview">
                    <h2>Profile Overview</h2>
                    <div class="text-center mb-3">
                        <?php if (!empty($doctor['profile_image'])): ?>
                            <img src="<?php echo htmlspecialchars($doctor['profile_image']); ?>" class="img-fluid" alt="Profile Photo">
                        <?php else: ?>
                            <img src="./img/dr.png" class="img-fluid" alt="Profile Photo">
                        <?php endif; ?>
                    </div>
                    <p><strong>Name:</strong> <?php echo "Dr. " . htmlspecialchars($doctor['name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($doctor['email']); ?></p>
                    <p><strong>Specialization:</strong> <?php echo htmlspecialchars($doctor['specialization']); ?></p>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($doctor['phone']); ?></p>
                    <h4>Appointments Summary</h4>
                    <?php
                    $result->data_seek(0); // Reset result pointer to the beginning
                    $totalAppointments = $result->num_rows;
                    echo "<p><strong>Total Appointments:</strong> $totalAppointments</p>";
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for adding prescription -->
    <div class="modal fade" id="addPrescriptionModal" tabindex="-1" role="dialog" aria-labelledby="addPrescriptionModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addPrescriptionModalLabel">Add Prescription</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label for="prescription">Prescription:</label>
                        <textarea class="form-control" id="prescription" rows="4"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="savePrescription">Save</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Include any additional scripts here -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
    function addPrescription(appointmentId) {
        $('#addPrescriptionModal').modal('show');
        $('#savePrescription').off('click').on('click', function() {
            var prescription = $('#prescription').val();
            $.ajax({
                url: 'doctor_dashboard.php',
                method: 'POST',
                data: {
                    savePrescription: true,
                    appointmentId: appointmentId,
                    prescription: prescription
                },
                success: function(response) {
                    $('#addPrescriptionModal').modal('hide');
                    alert(response);
                    // Refresh or update appointment list as needed
                },
                error: function(xhr, status, error) {
                    alert('Error saving prescription: ' + error);
                }
            });
        });
    }
    </script>

</body>
</html>
