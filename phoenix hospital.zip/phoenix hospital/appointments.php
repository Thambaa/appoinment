<?php
include "db.php";

$doctorId = isset($_GET['doctor_id']) ? intval($_GET['doctor_id']) : 0;

if ($doctorId == 0) {
    die("Invalid doctor ID.");
}


// Check if the user is accessing appointments from the admin dashboard
if (basename($_SERVER['HTTP_REFERER']) === 'admin_dashboard.php') {
    // If accessed from admin_dashboard.php, include staffheader.php
    include "staffheader.php";
} else {
    // Otherwise, include patientheader.php
    include "patientheader.php";
}






if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate the form data
    $patientName = $conn->real_escape_string($_POST['patientName']);
    $patientDOB = $conn->real_escape_string($_POST['patientDOB']);
    $patientAddress = $conn->real_escape_string($_POST['patientAddress']);
    $patientPhone = $conn->real_escape_string($_POST['patientPhone']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $bloodGroup = $conn->real_escape_string($_POST['bloodGroup']);
    $appointmentDate = $conn->real_escape_string($_POST['appointmentDate']);
    $consultedDoctor = intval($_POST['consultedDoctor']);

    // Perform SQL query to insert patient data into the database
    $sql = "INSERT INTO appointments (patient_name, dob, address, phone, gender, blood_group, doctor_id, appointment_date) 
            VALUES ('$patientName', '$patientDOB', '$patientAddress', '$patientPhone', '$gender', '$bloodGroup', '$consultedDoctor', '$appointmentDate')";

    
    if ($conn->query($sql) === TRUE) {
        $appointment_id = mysqli_insert_id($conn);
        $SQL = "INSERT INTO patients (name, dob, address, phone, gender, blood_group, doctor_id, appointment_id) 
        VALUES ('$patientName', '$patientDOB', '$patientAddress', '$patientPhone', '$gender', '$bloodGroup', '$consultedDoctor', '$appointment_id')";
        if ($conn->query($SQL)){
            echo "<div class='alert alert-success' role='alert'>New appointment & patient created successfully</div>";
        }else {
            echo "<div class='alert alert-success' role='alert'>New appointment only created successfully</div>";
        }

    } else {
        echo "<div class='alert alert-danger' role='alert'>Error: " . $sql . "<br>" . $conn->error . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Make an Appointment</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Arial', sans-serif;
        }
        .container {
            max-width: 800px;
            margin-top: 20px;
            margin-bottom: 20px;
        }
        form {
            background-color: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        }
        h2 {
            margin-bottom: 25px;
            color: #04AA6D;
            font-weight: bold;
            text-align: center;
        }
        .form-group label {
            font-weight: bold;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #04AA6D;
            border-color: #04AA6D;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            font-weight: bold;
        }
        .btn-primary:hover {
            background-color: #04AA6D;
            border-color: #04AA6D;
            opacity: 0.8;
        }
        .alert {
            margin-top: 20px;
        }
        .form-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .form-group {
            flex: 0 0 30%; /* Adjust the width as needed */
        }
    </style>
</head>
<body>

<div class="container">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) . '?doctor_id=' . $doctorId; ?>" method="post">
        <h2>Patient Appointment Form</h2>
        <div class="form-group">
            <label for="patientName">Name</label>
            <input type="text" class="form-control" id="patientName" name="patientName" required>
        </div>
        <div class="form-group">
            <label for="patientDOB">Date of Birth</label>
            <input type="date" class="form-control" id="patientDOB" name="patientDOB" required>
        </div>
        <div class="form-group">
            <label for="patientAddress">Address</label>
            <input type="text" class="form-control" id="patientAddress" name="patientAddress" required>
        </div>
        <div class="form-group">
            <label for="patientPhone">Phone Number</label>
            <input type="text" class="form-control" id="patientPhone" name="patientPhone" required>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label for="gender">Gender</label>
                <select class="form-control" id="gender" name="gender" required>
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
            <div class="form-group">
                <label for="bloodGroup">Blood Group</label>
                <select class="form-control" id="bloodGroup" name="bloodGroup" required>
                    <option value="">Select Blood Group</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                </select>
            </div>
            <div class="form-group">
                <label for="appointmentDate">Appointment Date</label>
                <input type="date" class="form-control" id="appointmentDate" name="appointmentDate" required>
            </div>
        </div>
        <input type="hidden" name="consultedDoctor" value="<?php echo $doctorId; ?>">
        <button type="submit" class="btn btn-primary btn-block">Add Appointment</button>
    </form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>
