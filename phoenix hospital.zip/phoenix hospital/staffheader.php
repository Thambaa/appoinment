<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
           @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400&display=swap');

           header {
    margin-bottom: 5px;
    background-color: rgba(255, 255, 255, 0.8);
}


.header-content {
    width: 90%;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 6px;
}

header img {
    height: 70px;
    width: 70px;
}

header .logo {
    margin-left: 20px;
}

header .nav-links {
    display: flex;
    justify-content: flex-end;
    list-style-type: none;
    margin: 0;
    padding: 0;
}

header .nav-links li {
    margin-left: 20px;
}

header a {
    display: block;
    padding: 10px 20px;
    color: #04AA6D;
    text-decoration: none;
    border-radius: 10px;
    transition: background-color 0.3s ease;
}
header .logo a:hover {
    background-color: transparent; 
}

header .nav-links a:hover {
    
    border-radius: 10px;
    text-decoration: none; 
}


header .nav-links i {
    margin-right: 5px;
}

.fa, .fas{
    color: #007ef4;
}
    </style>
</head>
<body>

<header>
    <div class="header-content">
    <div class="logo">
        <a href="index.php">
            <img src="./img/logo.png" alt="Hospital Logo">
        </a>
    </div>

        <ul class="nav-links">
            <li><a href="login.php"><i class="fa fa-id-card"></i>Login</a></li>
            <?php
            // Check the current script name and output the appropriate link
            if (strpos($_SERVER['PHP_SELF'], 'admin_dashboard.php') !== false) {
                echo '<li><a href="doctorlist.php"><i class="fas fa-user-md"></i>Make an Appointment</a></li>';
            } elseif (strpos($_SERVER['PHP_SELF'], 'doctorlist.php') !== false) {
                echo '<li><a href="index.php"><i class="fas fa-home"></i>Home</a></li>';
                echo '<li><a href="admin_dashboard.php"><i class="fas fa-user"></i>Admin</a></li>';
            } elseif (strpos($_SERVER['PHP_SELF'], 'appointments.php') !== false) {
                echo '<li><a href="index.php"><i class="fas fa-home"></i>Home</a></li>';
                echo '<li><a href="admin_dashboard.php"><i class="fas fa-user"></i>Admin</a></li>';
                echo '<li><a href="doctorlist.php"><i class="fas fa-user-md"></i>Change the Doctor</a></li>';
            }
            ?>
        </ul>
    </div>
</header>

</body>
</html>
