<?php
session_start();
include('db.php');

function loginUser($id, $role) {
    $_SESSION['user_id'] = $id;
    $_SESSION['role'] = $role;
    if ($role == 'admin') {
        header("Location: admin_dashboard.php");
    } else {
        header("Location: doctor_dashboard.php");
    }
    exit();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['psw'];

    $stmt = $conn->prepare("SELECT user_id, password, role FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $stored_password, $role);
        $stmt->fetch();

        if ($password == $stored_password) {  
            loginUser($id, $role);
        } else {
            $error_message = "Invalid password.";
        }
    } else {
        $error_message = "No user found with this username.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign-In</title>
    <!-- Include Bootstrap CSS and Font Awesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: url('./img/hpbg.jpg') no-repeat center center fixed; 
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .login-box {
            border: 2px solid #c6c3c3;
            border-radius: 10px;
            width: 450px;
            padding: 20px;
            background-color: #f9f9f9;
            box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
        }

        .field-icon {
            float: right;
            margin-left: -25px;
            margin-top: -25px;
            position: relative;
            z-index: 2;
            cursor: pointer;
            right: 10px;
        }

        .container {
            margin: auto;
        }

        button {
            background-color: #04AA6D;
            color: white;
            padding: 14px 20px;
            border-radius: 10px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            opacity: 0.8;
        }

        .imgcontainer {
            text-align: center;
            margin-bottom: 12px;
        }

        img.avatar {
            height: 80px;
            width: 80px;
            border-radius: 50%;
        }

        .welcome-message h1 {
            font-weight: bold;
            text-align: left;
            margin-bottom: 10px;
            margin-left: 15px;
        }

        .welcome-message h5 {
            font-weight: bold;
            text-align: left;
            margin-bottom: 10px;
            margin-left: 15px;
            color: #04AA6D
        }

.welcome-message h6 {
    text-align: left;
    margin-bottom: 30px;
    margin-left: 15px;
    font-size: small;
}

.logo {
    text-align: center;
    margin-bottom: 20px;
}

.logo img {
    width: 100px; 
}
</style>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>

<body>
<div class="login-box">
<div class="logo">
    <a href="index.php">
        <img src="./img/logo.png" alt="Hospital Logo"> 
    </a>
</div>


<div class="welcome-message">
<h1>Welcome to Phoenix</h1>
<h5>Hospital Management System</h5>
<h6>Sign in to start your session</h6>
</div>
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
<div class="container">
    <div class="form-group">
        <label for="username"><b>Username</b></label>
        <input type="text" class="form-control" placeholder="Enter Username" name="username" required>
    </div>

    <div class="form-group">
        <label for="psw"><b>Password</b></label>
        <div style="position: relative;">
            <input type="password" class="form-control" placeholder="Enter Password" name="psw" id="password-field" required>
            <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
        </div>
    </div>
        <button type="submit">Login</button>
    </div>

<!-- Display error message if login fails -->
<?php if(isset($error_message)) { ?>
    <div style="color: red; text-align: center;"><?php echo $error_message; ?></div>
<?php } ?>
</form>
</div>

<script>
$(".toggle-password").click(function() {
$(this).toggleClass("fa-eye fa-eye-slash");
var input = $($(this).attr("toggle"));
if (input.attr("type") == "password") {
    input.attr("type", "text");
} else {
    input.attr("type", "password");
}
});
</script>

</body>
</html>
