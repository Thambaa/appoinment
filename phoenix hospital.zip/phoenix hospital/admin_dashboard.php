<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit();
}


include "db.php";

// Function to handle database errors
function handleDatabaseError($conn) {
    echo "Error: " . $conn->error;
}

//time
function convertTo12HourFormat($time) {
    $date = DateTime::createFromFormat('H:i:s', $time);
    return $date->format('h:i A');
}


// Check if form submitted for adding a doctor
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'addDoctor') {
    if (isset($_POST['doctorName'], $_POST['doctorSpecialization'], $_POST['doctorDay'], $_POST['doctorInTime'], $_POST['doctorOutTime'], $_POST['doctorEmail'], $_POST['doctorPhone'])) {
        
        $doctorName =  $_POST['doctorName'];
        $doctorSpecialization = $_POST['doctorSpecialization'];
        $doctorDay = $_POST['doctorDay'];
        
        $doctorInTime = $_POST['doctorInTime'];
        $doctorOutTime = $_POST['doctorOutTime'];
        $doctorEmail = $_POST['doctorEmail'];
        $doctorPhone = $_POST['doctorPhone'];

        // Handle profile image upload
        $profileImage = '';
        if (isset($_FILES['doctorProfileImage']) && $_FILES['doctorProfileImage']['error'] === UPLOAD_ERR_OK) {
            $profileImageTmpPath = $_FILES['doctorProfileImage']['tmp_name'];
            $profileImageName = basename($_FILES['doctorProfileImage']['name']);
            $uploadDir = 'uploads/'; // Ensure this directory exists and is writable
            $profileImage = $uploadDir . $profileImageName;

            if (!move_uploaded_file($profileImageTmpPath, $profileImage)) {
                echo "Error uploading profile image.";
                exit();
            }
        }
        

        $sql = "INSERT INTO doctors (name, specialization, day, in_time, out_time, email, phone, profile_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssss", $doctorName, $doctorSpecialization, $doctorDay, $doctorInTime, $doctorOutTime, $doctorEmail, $doctorPhone, $profileImage);

        if ($stmt->execute()) {
            echo "Doctor added successfully!";
        } else {
            handleDatabaseError($conn);
        }

        $stmt->close();
    }
}


// Check if form submitted for updating a doctor

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'updateDoctor') {
    if (isset($_POST['doctorId'], $_POST['editDoctorName'], $_POST['editDoctorSpecialization'], $_POST['editDoctorDay'], $_POST['editDoctorInTime'], $_POST['editDoctorOutTime'], $_POST['editDoctorEmail'], $_POST['editDoctorPhone'])) {
        $doctorId = $_POST['doctorId'];
        $editDoctorName = $_POST['editDoctorName'];
        $editDoctorSpecialization = $_POST['editDoctorSpecialization'];
        $editDoctorDay = $_POST['editDoctorDay'];
        $editDoctorInTime = $_POST['editDoctorInTime'];
        $editDoctorOutTime = $_POST['editDoctorOutTime'];
        $editDoctorEmail = $_POST['editDoctorEmail'];
        $editDoctorPhone = $_POST['editDoctorPhone'];

        // Handle profile image update
        $profileImage = ''; // Initialize profile image variable

        // Check if a new profile image is uploaded
        if (isset($_FILES['editProfileImage']) && $_FILES['editProfileImage']['error'] === UPLOAD_ERR_OK) {
            $profileImageTmpPath = $_FILES['editProfileImage']['tmp_name'];
            $profileImageName = basename($_FILES['editProfileImage']['name']);
            $uploadDir = 'uploads/';
            $profileImage = $uploadDir . $profileImageName;

            // Move the uploaded image to the desired directory
            if (!move_uploaded_file($profileImageTmpPath, $profileImage)) {
                echo "Error uploading profile image.";
                exit();
            }
        }

        // Prepare and execute the SQL update statement
        $sql = "UPDATE doctors SET name=?, specialization=?, day=?, in_time=?, out_time=?, email=?, phone=?, profile_image=? WHERE doctor_id=?";
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bind_param("ssssssssi", $editDoctorName, $editDoctorSpecialization, $editDoctorDay, $editDoctorInTime, $editDoctorOutTime, $editDoctorEmail, $editDoctorPhone, $profileImage, $doctorId);

        // Execute the statement
        if ($stmt->execute()) {
            echo "Doctor updated successfully!";
        } else {
            handleDatabaseError($conn);
        }

        // Close the statement
        $stmt->close();
    }
}






// Check if form submitted for adding a patient
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'addPatient') {
        if (isset($_POST['patientName'], $_POST['patientDOB'], $_POST['patientAddress'], $_POST['patientPhone'], $_POST['gender'], $_POST['bloodGroup'], $_POST['consultedDoctor'])) {
        $patientName = ($_POST['patientName']);
        $patientDOB = ($_POST['patientDOB']);
        $patientAddress = ($_POST['patientAddress']);
        $patientPhone = ($_POST['patientPhone']);
        $gender = ($_POST['gender']);
        $bloodGroup = ($_POST['bloodGroup']);
        $consultedDoctor = ($_POST['consultedDoctor']);
        $doctorPrescription = ($_POST['doctorPrescription']);
        
        $sql = "INSERT INTO patients (name, dob, address, phone, gender, blood_group, doctor_id, prescription) VALUES (?, ?, ?, ?, ?,?,?,?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssis", $patientName, $patientDOB, $patientAddress, $patientPhone, $gender, $bloodGroup, $consultedDoctor, $doctorPrescription );

        if ($stmt->execute()) {
            echo "New record created successfully";
        } else {
            handleDatabaseError($conn);
        }

        $stmt->close();

        }
    }
    

            


// Check if form submitted for updating a patient
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'updatePatient') {
        if (isset($_POST['patientId'], $_POST['editPatientName'], $_POST['editPatientDOB'], $_POST['editPatientAddress'], $_POST['editPatientPhone'], $_POST['editGender'], $_POST['editBloodGroup'], $_POST['editConsultedDoctor'], $_POST['editDoctorPrescription'])) {
            $patientId = $_POST['patientId'];
            $editPatientName = $_POST['editPatientName'];
            $editPatientDOB = $_POST['editPatientDOB'];
            $editPatientAddress = $_POST['editPatientAddress'];
            $editPatientPhone = $_POST['editPatientPhone'];
            $editGender = $_POST['editGender'];
            $editBloodGroup = $_POST['editBloodGroup'];
            $editConsultedDoctor = $_POST['editConsultedDoctor'];
            $editDoctorPrescription = $_POST['editDoctorPrescription'];

            $sql = "UPDATE patients SET name=?, dob=?, address=?, phone=?, gender=?, blood_group=?, doctor_name=?, prescription=? WHERE doctor_id=?";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssi", $editPatientName, $editPatientDOB, $editPatientAddress, $editPatientPhone, $editGender, $editBloodGroup, $editConsultedDoctor, $editDoctorPrescription, $patientId);

            if ($stmt->execute()) {
                echo "Patient updated successfully!";
            } else {
                handleDatabaseError($conn);
            }

            $stmt->close();
        }
    }

    // Check if form submitted for creating a doctor login
    
    
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['action']) && $_POST['action'] === 'createDoctorLogin') {
        if (isset($_POST['doctorId'], $_POST['username'], $_POST['password'])) {
            $doctorId = $_POST['doctorId'];
            $username = $_POST['username'];
            $password = $_POST['password'];
            $role = 'doctor';
    
            // Prepare the SQL update statement
            $sql = "UPDATE users SET username = ?, password = ?, role = ? WHERE user_id = ?";
            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                handleDatabaseError($conn);
                exit;
            }
    
            // Bind parameters
            $stmt->bind_param("sssi", $username, $password, $role, $doctorId);
    
            // Execute the statement
            if ($stmt->execute()) {
                echo "Doctor login updated successfully!";
            } else {
                handleDatabaseError($conn);
            }
    
            // Close the statement
            $stmt->close();
        } else {
            echo "Required fields are missing.";
        }
    }
    

    
    
    
    
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
        }
        .main {
            display: flex;
            height: calc(100vh - 50px); 
        }
        
        .sidebar {
            width: 25%;
            background-color: #f8f9fa;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        }
        .content {
            flex: 1;
            padding: 20px;
        }
        .sidebar .nav-item {
            margin: 15px 0;
        }
        .content-section {
            display: none;
        }
        .table {
            background-color: #f8f9fa;
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
            border: 1px solid #ddd;
            border-radius: 5px;
            overflow: hidden;
        }


        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #ddd;
        }

        .container {
            margin-top: 50px;
        }

        .sidebar {
            background-color: #f8f9fa;
            padding: 20px;
            border-right: 1px solid #dee2e6;
        }

        .content {
            padding: 20px;
        }

        .content-section {
            margin-bottom: 20px;
        }

    </style>
</head>
<body>

<div class="header">
    <?php include "staffheader.php"; ?>
</div>
<div class="main">
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
            <a class="nav-link active" id="v-pills-add-doctor-tab" data-toggle="pill" href="#v-pills-add-doctor" role="tab" aria-controls="v-pills-add-doctor" aria-selected="true">Add Doctor</a>
            <a class="nav-link" id="v-pills-edit-doctor-tab" data-toggle="pill" href="#v-pills-edit-doctor" role="tab" aria-controls="v-pills-edit-doctor" aria-selected="false">Edit Doctor</a>
            <a class="nav-link" id="v-pills-doctor-records-tab" data-toggle="pill" href="#v-pills-doctor-records" role="tab" aria-controls="v-pills-doctor-records" aria-selected="false">Doctor Records</a>
            <a class="nav-link" id="v-pills-add-patient-tab" data-toggle="pill" href="#v-pills-add-patient" role="tab" aria-controls="v-pills-add-patient" aria-selected="false">Add Patient</a>
            <a class="nav-link" id="v-pills-edit-patient-tab" data-toggle="pill" href="#v-pills-edit-patient" role="tab" aria-controls="v-pills-edit-patient" aria-selected="false">Edit Patient</a>
            <a class="nav-link" id="v-pills-patient-records-tab" data-toggle="pill" href="#v-pills-patient-records" role="tab" aria-controls="v-pills-patient-records" aria-selected="false">Patient Records</a>
            <a class="nav-link" id="v-pills-add-doctor-log-tab" data-toggle="pill" href="#v-pills-add-doctor-log" role="tab" aria-controls="v-pills-add-doctor-log" aria-selected="false">Add Doctor Login</a>
        </div>
    </div>
    <div class="content">
        <div class="tab-content" id="v-pills-tabContent">
            <!-- Add Doctor Section -->
            <div class="tab-pane fade show active content-section" id="v-pills-add-doctor" role="tabpanel" aria-labelledby="v-pills-add-doctor-tab">
                <h2>Add Doctor</h2>
                <form action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="addDoctor">
                    <div class="form-group">
                        <label for="doctorName">Doctor Name</label>
                        <input type="text" name="doctorName" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorSpecialization">Specialization</label>
                        <select name="doctorSpecialization" class="form-control" required>
                            <option value="">Select Specialization</option>
                            <option value="Cardiology">Cardiology</option>
                            <option value="Dermatology">Dermatology</option>
                            <option value="Neurology">Neurology</option>
                            <option value="Pediatrics">Pediatrics</option>
                            <option value="Psychiatry">Psychiatry</option>
                            <option value="Surgery">Surgery</option>
                            <!-- Add more specializations as needed -->
                        </select>
                        
                    </div>
                    <div class="form-group">
                        <label for="doctorDay">Day</label>
                        <select name="doctorDay" class="form-control" required>
                            <option value="">Select Day</option>
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                            <option value="Saturday">Saturday</option>
                            <option value="Sunday">Sunday</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="doctorInTime">In Time</label>
                        <input type="time" name="doctorInTime" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorOutTime">Out Time</label>
                        <input type="time" name="doctorOutTime" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorEmail">Email</label>
                        <input type="email" name="doctorEmail" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorPhone">Phone</label>
                        <input type="tel" name="doctorPhone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="doctorProfileImage">Profile Image</label>
                        <input type="file" name="doctorProfileImage" class="form-control-file" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Add Doctor</button>
                </form>
            </div>


            <!-- Edit Doctor Section -->
            <div class="tab-pane fade content-section" id="v-pills-edit-doctor" role="tabpanel" aria-labelledby="v-pills-edit-doctor-tab">
                <h2>Edit Doctor</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <input type="hidden" name="action" value="updateDoctor">
                    <div class="form-group">
                        <label for="doctorId">Doctor ID</label>
                        <input type="number" name="doctorId" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="editDoctorName">Doctor Name</label>
                        <input type="text" name="editDoctorName" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="editDoctorSpecialization">Specialization</label>
                        <select name="editDoctorSpecialization" class="form-control" required>
                            <option value="">Select Specialization</option>
                            <option value="Cardiology">Cardiology</option>
                            <option value="Dermatology">Dermatology</option>
                            <option value="Neurology">Neurology</option>
                            <option value="Pediatrics">Pediatrics</option>
                            <option value="Psychiatry">Psychiatry</option>
                            <option value="Surgery">Surgery</option>
                            <!-- Add more specializations as needed -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="editDoctorDay">Day</label>
                        <select name="editDoctorDay" class="form-control" required>
                            <option value="">Select Day</option>
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                            <option value="Saturday">Saturday</option>
                            <option value="Sunday">Sunday</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="editDoctorInTime">In Time</label>
                        <input type="time" name="editDoctorInTime" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="editDoctorOutTime">Out Time</label>
                        <input type="time" name="editDoctorOutTime" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="editDoctorEmail">Email</label>
                        <input type="email" name="editDoctorEmail" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="editDoctorPhone">Phone</label>
                        <input type="tel" name="editDoctorPhone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="editProfileImage">Profile Image</label>
                        <input type="file" name="editProfileImage" class="form-control-file">
                    </div>
                    <button type="submit" class="btn btn-primary">Update Doctor</button>
                </form>
            </div>

            <!-- Doctor Records Section -->
            <div class="tab-pane fade content-section" id="v-pills-doctor-records" role="tabpanel" aria-labelledby="v-pills-doctor-records-tab">
    <h2>Doctor Records</h2>
    <?php
                $sql = "SELECT * FROM doctors";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
        echo "<table class='table'>";
                    echo "<thead><tr><th>ID</th><th>Name</th><th>Specialization</th><th>Day</th><th>In Time</th><th>Out Time</th></tr></thead>";
        echo "<tbody>";
        while ($row = $result->fetch_assoc()) {
            $in_time_12hr = convertTo12HourFormat($row["in_time"]);
            $out_time_12hr = convertTo12HourFormat($row["out_time"]);
            echo "<tr>";
            echo "<td>" . $row["doctor_id"] . "</td>";
            echo "<td>Dr. " . $row["name"] . "</td>";
            echo "<td>" . $row["specialization"] . "</td>";
            echo "<td>" . $row["day"] . "</td>";
            echo "<td>" . $in_time_12hr . "</td>";
            echo "<td>" . $out_time_12hr . "</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
        } else {
        echo "No records found.";
        }
    ?>
</div>


           <!-- Add Patient Section -->
            <div class="tab-pane fade content-section" id="v-pills-add-patient" role="tabpanel" aria-labelledby="v-pills-add-patient-tab">
                <h2>Add Patient</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <input type="hidden" name="action" value="addPatient">
                    <div class="form-group">
                        <label for="patientName">Patient Name</label>
                        <input type="text" name="patientName" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="patientDOB">DOB</label>
                        <input type="date" name="patientDOB" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="patientAddress">Address</label>
                        <input type="text" name="patientAddress" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="patientPhone">Phone</label>
                        <input type="tel" name="patientPhone" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select name="gender" class="form-control" required>
                            <option value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="bloodGroup">Blood Group</label>
                        <select class="form-control" id="bloodGroup" name="bloodGroup" required>
                            <option value="">Select Blood Group</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="consultedDoctor">Consulted Doctor</label>
                        <select class="form-control" id="consultedDoctor" name="consultedDoctor" required>
                        <?php
                        $sql = "SELECT doctor_id, CONCAT('Dr. ', name) AS doctor_name FROM doctors"; // Prepend "Dr." to the doctor's name
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["doctor_id"] . "'>" . $row["doctor_name"] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No doctors available</option>";
                        }
                        ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="doctorPrescription">Prescription</label>
                        <input type="text" name="doctorPrescription" class="form-control" >
                    </div>
                    <button type="submit" class="btn btn-primary">Add Patient</button>
                </form>
            </div>

            <!-- Edit Patient Section -->
            
            <div class="tab-pane fade content-section" id="v-pills-edit-patient" role="tabpanel" aria-labelledby="v-pills-edit-patient-tab">
                <h2>Edit Patient</h2>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <input type="hidden" name="action" value="updatePatient">
                    <div class="form-group">
                        <label for="patientId">Patient ID</label>
                        <input type="number" name="patientId" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="editPatientName">Patient Name</label>
                        <input type="text" name="editPatientName" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="editPatientDOB">DOB</label>
                        <input type="date" name="editPatientDOB" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="editPatientAddress">Address</label>
                        <input type="text" name="editPatientAddress" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="editPatientPhone">Phone</label>
                        <input type="tel" name="editPatientPhone" class="form-control" >
                    </div>
                    <div class="form-group">
                        <label for="editGender">Gender</label>
                        <select name="editGender" class="form-control" >
                            <option value="">Select Gender</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                        </select>
                    </div>
                    <div class="form-group">
            <label for="editBloodGroup">Blood Group</label>
            <select class="form-control" id="editBloodGroup" name="editBloodGroup" >
                <option value="">Select Blood Group</option>
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
            </select>
        </div>
            <div class="form-group">
                <label for="editConsultedDoctor">Consulted Doctor</label>
                <select class="form-control" id="editConsultedDoctor" name="editConsultedDoctor" >
                <?php
                        $sql = "SELECT doctor_id, CONCAT('Dr. ', name) AS doctor_name FROM doctors"; // Prepend "Dr." to the doctor's name
                        $result = $conn->query($sql);
                        
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row["doctor_id"] . "'>" . $row["doctor_name"] . "</option>";
                            }
                        } else {
                            echo "<option value=''>No doctors available</option>";
                        }
                        ?>
                </select>
            </div>
            
            <div class="form-group">
                        <label for="editDoctorPrescription">Prescription</label>
                        <input type="text" name="editDoctorPrescription" class="form-control" >
            </div>

                    <button type="submit" class="btn btn-primary">Update Patient</button>
                </form>
            </div>

        <!-- Patient Records Section -->
        <div class="tab-pane fade content-section" id="v-pills-patient-records" role="tabpanel" aria-labelledby="v-pills-patient-records-tab">
            <h2>Patient Records</h2>
            <?php
            $sql = "SELECT patients.id, patients.name AS patient_name, patients.dob, patients.address, patients.phone, patients.gender, patients.blood_group, doctors.name AS doctor_name, patients.prescription
                    FROM patients
                    JOIN doctors ON patients.doctor_id = doctors.doctor_id";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<table class='table'>";
                echo "<thead><tr><th>ID</th><th>Name</th><th>DOB</th><th>Address</th><th>Phone</th><th>Gender</th><th>Blood Group</th><th>Consulted Doctor</th><th>Prescription</th></tr></thead>";
                echo "<tbody>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>{$row['id']}</td>";
                    echo "<td>{$row['patient_name']}</td>";
                    echo "<td>{$row['dob']}</td>";
                    echo "<td>{$row['address']}</td>";
                    echo "<td>{$row['phone']}</td>";
                    echo "<td>{$row['gender']}</td>";
                    echo "<td>{$row['blood_group']}</td>";
                    echo "<td>Dr. " . $row["doctor_name"] . "</td>";
                    echo "<td>{$row['prescription']}</td>";
                    echo "</tr>";
                }
                echo "</tbody></table>";
            } else {
                echo "No records found.";
            }
            ?>
        </div>

        <div class="tab-pane fade" id="v-pills-add-doctor-log" role="tabpanel" aria-labelledby="v-pills-add-doctor-log-tab">
    <h2>Add Doctor Login</h2>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="hidden" name="action" value="createDoctorLogin">
        <div class="form-group">
            <label for="doctorId">Doctor ID</label>
            <select name="doctorId" class="form-control" required>
                <?php
                $sql = "SELECT user_id, name FROM doctors";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['user_id'] . "'>" . $row['user_id'] . " - " . $row['name'] . "</option>";
                    }
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="text" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Doctor Login</button>
    </form>
</div>

</div>



<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>


<script>

    // Populate consulted doctor dropdowns in add and edit patient forms
    $.ajax({
        url: "<?php echo $_SERVER['PHP_SELF']; ?>", // Assuming this script returns doctor records
        type: "POST",
        success: function(response) {
            $('#consultedDoctor, #editConsultedDoctor').html(response);
        }
    });

    // Handle form submission for editing doctor details
    $('#editDoctorForm').on('submit', function(e) {
        e.preventDefault();
        // Fetch doctor details and display in the form
        $('#editDoctorDetails').show();
    });


    // Handle form submission for editing patient details
    $('#editpatientForm').on('submit', function(e) {
        e.preventDefault();
        // Fetch patient details and display in the form
        $('#editpatientDetails').show();
    });


</script>




</body>
</html>
