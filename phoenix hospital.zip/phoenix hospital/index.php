<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Phoenix Hospitals</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-image: url('./img/ibg.jpg'); 
            background-size: cover;
            background-position: center;
            font-family: Arial, sans-serif;
            color: #fff;
            text-align: left; 
        }
        .welcome-section {
            display: flex;
            justify-content: center; 
            align-items: center;
            height: 80vh; 
            
        }
        .welcome-text {
            
            margin: 0 auto;
            text-align: center;
           
        }
        h1 {
            font-size: 48px;
            margin-bottom: 20px;
            color: #04AA6D;
        }
        button {
            padding: 10px 20px;
            font-size: 18px;
            background-color: #04AA6D;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #fff;
            color:#04AA6D;
        }
        .punchline {
            font-size: 24px;
            margin-top: 20px;
            color: #007ef4;
        }
    </style>
</head>
<body>
    <?php include 'patientheader.php'; ?>
    <div class="welcome-section">
        <div class="welcome-text">
            <h1>Welcome to Phoenix Hospitals (Pvt) Ltd.</h1>
            
            <p class="punchline">"Caring for you, every step of the way"</p>
            <button onclick="makeAppointment()">Make an Appointment</button>
        </div>
    </div>
    <script>
        function makeAppointment() {
            window.location.href = "doctorlist.php"; 
        }
    </script>
</body>
</html>
